A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/MagROe.

 

Forked from [Christophe Béghin](http://codepen.io/CBeghin/)'s Pen [Animated search Form](http://codepen.io/CBeghin/pen/HeuiF/).